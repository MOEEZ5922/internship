import { createBrowserRouter } from "react-router";
import RoleSelector from "./pages/RoleSelector";
import PhysicianLayout from "./layouts/PhysicianLayout";
import TechnicianLayout from "./layouts/TechnicianLayout";
import PatientLayout from "./layouts/PatientLayout";
import PhysicianHome from "./pages/physician/Home";
import PhysicianBiomarkers from "./pages/physician/Biomarkers";
import PhysicianInterventions from "./pages/physician/Interventions";
import PhysicianSurveys from "./pages/physician/Surveys";
import TechnicianHome from "./pages/technician/Home";
import TechnicianCPAP from "./pages/technician/CPAP";
import TechnicianInterventions from "./pages/technician/Interventions";
import TechnicianSurveys from "./pages/technician/Surveys";
import PatientHome from "./pages/patient/Home";
import PatientCPAP from "./pages/patient/CPAP";
import PatientSurveys from "./pages/patient/Surveys";
import PatientVideos from "./pages/patient/Videos";
import PatientHelp from "./pages/patient/Help";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: RoleSelector,
  },
  {
    path: "/physician",
    Component: PhysicianLayout,
    children: [
      { index: true, Component: PhysicianHome },
      { path: "biomarkers", Component: PhysicianBiomarkers },
      { path: "interventions", Component: PhysicianInterventions },
      { path: "surveys", Component: PhysicianSurveys },
    ],
  },
  {
    path: "/technician",
    Component: TechnicianLayout,
    children: [
      { index: true, Component: TechnicianHome },
      { path: "cpap", Component: TechnicianCPAP },
      { path: "interventions", Component: TechnicianInterventions },
      { path: "surveys", Component: TechnicianSurveys },
    ],
  },
  {
    path: "/patient",
    Component: PatientLayout,
    children: [
      { index: true, Component: PatientHome },
      { path: "cpap", Component: PatientCPAP },
      { path: "surveys", Component: PatientSurveys },
      { path: "videos", Component: PatientVideos },
      { path: "help", Component: PatientHelp },
    ],
  },
]);