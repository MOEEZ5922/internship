import { Outlet, Link, useLocation } from 'react-router';
import { Home, Activity, Package, FileText, Settings, ArrowLeft } from 'lucide-react';
import { patientInfo } from '../data/mockData';

const navigation = [
  { name: 'Home', href: '/technician', icon: Home },
  { name: 'CPAP', href: '/technician/cpap', icon: Activity },
  { name: 'Interventions', href: '/technician/interventions', icon: Package },
  { name: 'Medical Surveys', href: '/technician/surveys', icon: FileText },
];

export default function TechnicianLayout() {
  const location = useLocation();

  return (
    <div className="h-screen flex bg-[#FAFAFA]">
      {/* Left Sidebar */}
      <div className="w-64 bg-white border-r border-[#E8EEF2] flex flex-col">
        <div className="p-6 border-b border-[#E8EEF2]">
          <Link to="/" className="flex items-center gap-2 text-[#5A6B7C] hover:text-[#0A1128] transition-colors mb-4">
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm">Back to Portal</span>
          </Link>
          <h1 className="text-2xl text-[#0A1128] mb-1">
            SleepCare
          </h1>
          <p className="text-sm text-[#5A6B7C]">Technician Portal</p>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          {navigation.map((item) => {
            const isActive = location.pathname === item.href || (location.pathname === '/technician' && item.href === '/technician/cpap');
            const Icon = item.icon;

            return (
              <Link
                key={item.name}
                to={item.href}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                  isActive
                    ? 'bg-[#F4A261] text-white shadow-sm'
                    : 'text-[#5A6B7C] hover:bg-[#E8EEF2] hover:text-[#0A1128]'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-sm font-medium">{item.name}</span>
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-[#E8EEF2]">
          <button className="flex items-center gap-3 px-4 py-3 rounded-lg text-[#5A6B7C] hover:bg-[#E8EEF2] hover:text-[#0A1128] transition-all w-full">
            <Settings className="w-5 h-5" />
            <span className="text-sm font-medium">Settings</span>
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <div className="bg-white border-b border-[#E8EEF2] px-8 py-4">
          <div className="flex items-center gap-6">
            <div>
              <p className="text-xs text-[#5A6B7C] mb-1">Patient Name</p>
              <p className="font-semibold text-[#0A1128]">{patientInfo.name}</p>
            </div>
            <div className="w-px h-10 bg-[#E8EEF2]" />
            <div>
              <p className="text-xs text-[#5A6B7C] mb-1">Address</p>
              <p className="text-[#0A1128]">{patientInfo.address}</p>
            </div>
            <div className="w-px h-10 bg-[#E8EEF2]" />
            <div>
              <p className="text-xs text-[#5A6B7C] mb-1">Machine Serial</p>
              <p className="text-[#0A1128] font-mono text-sm">{patientInfo.machineSerial}</p>
            </div>
            <div className="w-px h-10 bg-[#E8EEF2]" />
            <div>
              <p className="text-xs text-[#5A6B7C] mb-1">Mask Type</p>
              <p className="text-[#0A1128]">{patientInfo.maskType}</p>
            </div>
          </div>
        </div>

        {/* Page Content */}
        <div className="flex-1 overflow-auto">
          <Outlet />
        </div>
      </div>
    </div>
  );
}