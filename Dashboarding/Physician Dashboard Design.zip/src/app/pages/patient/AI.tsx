import { aiData } from '../../data/mockData';
import { TrendingUp, Sparkles, Lightbulb } from 'lucide-react';

export default function PatientAI() {
  return (
    <div className="p-6 space-y-6">
      {/* Weekly Message */}
      <div className="bg-gradient-to-br from-[#6A994E] to-[#4a7a35] rounded-2xl p-8 text-white shadow-lg">
        <div className="flex items-center gap-3 mb-4">
          <Sparkles className="w-8 h-8" />
          <h2 className="text-2xl font-semibold">This Week's Wrap-Up</h2>
        </div>
        <p className="text-xl text-white/95 leading-relaxed">{aiData.patient.weeklyMessage}</p>
      </div>

      {/* Improvements */}
      <div className="bg-white rounded-2xl p-6 shadow-sm">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 bg-[#2D9596]/10 rounded-full flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-[#2D9596]" />
          </div>
          <h3 className="text-lg text-[#0A1128]">Your Improvements</h3>
        </div>

        <div className="space-y-3">
          {aiData.patient.improvements.map((improvement, index) => (
            <div
              key={index}
              className="flex items-start gap-3 p-4 bg-gradient-to-r from-[#6A994E]/5 to-[#2D9596]/5 rounded-xl border border-[#6A994E]/10"
            >
              <div className="w-6 h-6 bg-[#6A994E] text-white rounded-full flex items-center justify-center flex-shrink-0 text-sm font-medium">
                {index + 1}
              </div>
              <p className="text-[#0A1128] flex-1">{improvement}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Weekly Tip */}
      <div className="bg-gradient-to-br from-[#F4A261]/10 to-[#F4A261]/5 border-2 border-[#F4A261]/20 rounded-2xl p-6">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 bg-[#F4A261]/20 rounded-full flex items-center justify-center flex-shrink-0">
            <Lightbulb className="w-6 h-6 text-[#F4A261]" />
          </div>
          <div className="flex-1">
            <h3 className="text-lg text-[#0A1128] mb-2">Tip of the Week</h3>
            <p className="text-[#5A6B7C] leading-relaxed">{aiData.patient.tip}</p>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white rounded-xl p-4 shadow-sm text-center">
          <p className="text-3xl font-bold text-[#6A994E] mb-1">6.8</p>
          <p className="text-xs text-[#5A6B7C]">Avg Hours/Night</p>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-sm text-center">
          <p className="text-3xl font-bold text-[#2D9596] mb-1">85</p>
          <p className="text-xs text-[#5A6B7C]">Sleep Quality</p>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-sm text-center">
          <p className="text-3xl font-bold text-[#F4A261] mb-1">4</p>
          <p className="text-xs text-[#5A6B7C]">Day Streak</p>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-sm text-center">
          <p className="text-3xl font-bold text-[#6A994E] mb-1">+15%</p>
          <p className="text-xs text-[#5A6B7C]">vs Last Week</p>
        </div>
      </div>

      {/* Encouragement */}
      <div className="bg-white rounded-2xl p-6 shadow-sm text-center">
        <p className="text-2xl mb-3">🎉</p>
        <p className="text-lg text-[#0A1128] font-medium mb-2">You're doing amazing!</p>
        <p className="text-sm text-[#5A6B7C]">
          Keep up the great work. Every night of therapy brings you closer to better health and
          more energy.
        </p>
      </div>
    </div>
  );
}
