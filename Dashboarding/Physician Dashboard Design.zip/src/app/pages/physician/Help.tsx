import { Book, FileText, Mail } from 'lucide-react';

export default function PhysicianHelp() {
  return (
    <div className="p-8 max-w-4xl">
      <div className="mb-6">
        <h2 className="text-2xl text-[#0A1128] mb-2">Help & Support</h2>
        <p className="text-[#5A6B7C]">Access documentation and support resources</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* System Documentation */}
        <div className="bg-white rounded-xl border border-[#E8EEF2] shadow-sm p-6 hover:shadow-lg transition-shadow">
          <div className="w-12 h-12 bg-[#2D9596]/10 rounded-lg flex items-center justify-center mb-4">
            <Book className="w-6 h-6 text-[#2D9596]" />
          </div>
          <h3 className="text-lg text-[#0A1128] mb-2">System Documentation</h3>
          <p className="text-sm text-[#5A6B7C] mb-4">
            Comprehensive guides for using the platform and interpreting data
          </p>
          <button className="text-[#2D9596] hover:underline text-sm font-medium">
            View Documentation →
          </button>
        </div>

        {/* Clinical Protocols */}
        <div className="bg-white rounded-xl border border-[#E8EEF2] shadow-sm p-6 hover:shadow-lg transition-shadow">
          <div className="w-12 h-12 bg-[#F4A261]/10 rounded-lg flex items-center justify-center mb-4">
            <FileText className="w-6 h-6 text-[#F4A261]" />
          </div>
          <h3 className="text-lg text-[#0A1128] mb-2">Clinical Protocol Guidelines</h3>
          <p className="text-sm text-[#5A6B7C] mb-4">
            Evidence-based protocols for sleep apnea treatment and management
          </p>
          <button className="text-[#F4A261] hover:underline text-sm font-medium">
            View Guidelines →
          </button>
        </div>

        {/* Contact Support */}
        <div className="bg-white rounded-xl border border-[#E8EEF2] shadow-sm p-6 hover:shadow-lg transition-shadow">
          <div className="w-12 h-12 bg-[#6A994E]/10 rounded-lg flex items-center justify-center mb-4">
            <Mail className="w-6 h-6 text-[#6A994E]" />
          </div>
          <h3 className="text-lg text-[#0A1128] mb-2">Contact Software Support</h3>
          <p className="text-sm text-[#5A6B7C] mb-4">
            Get help from our technical support team
          </p>
          <button className="text-[#6A994E] hover:underline text-sm font-medium">
            Contact Support →
          </button>
        </div>
      </div>

      {/* FAQ Section */}
      <div className="mt-8 bg-white rounded-xl border border-[#E8EEF2] shadow-sm p-6">
        <h3 className="text-lg text-[#0A1128] mb-4">Frequently Asked Questions</h3>
        <div className="space-y-4">
          <div className="pb-4 border-b border-[#E8EEF2]">
            <h4 className="text-[#0A1128] font-medium mb-2">
              How is the AI risk score calculated?
            </h4>
            <p className="text-sm text-[#5A6B7C]">
              The AI risk score uses machine learning algorithms trained on over 100,000 patient
              records to identify patterns associated with clinical deterioration, analyzing AHI
              trends, compliance data, biomarkers, and survey responses.
            </p>
          </div>

          <div className="pb-4 border-b border-[#E8EEF2]">
            <h4 className="text-[#0A1128] font-medium mb-2">
              What is the recommended AHI target?
            </h4>
            <p className="text-sm text-[#5A6B7C]">
              For patients on CPAP therapy, the target AHI is typically &lt;5 events per hour.
              Values between 5-15 indicate mild residual sleep apnea, 15-30 is moderate, and &gt;30
              is severe.
            </p>
          </div>

          <div>
            <h4 className="text-[#0A1128] font-medium mb-2">
              How often is patient data synchronized?
            </h4>
            <p className="text-sm text-[#5A6B7C]">
              CPAP machine data is automatically synchronized daily when the patient's device
              connects via cellular or WiFi. Biomarker data from wearables syncs in real-time when
              available.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
