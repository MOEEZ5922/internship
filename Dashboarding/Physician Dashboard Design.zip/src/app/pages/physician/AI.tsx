import { aiData } from '../../data/mockData';
import { AlertTriangle, TrendingUp, CheckCircle } from 'lucide-react';

export default function PhysicianAI() {
  const getRiskColor = (level: string) => {
    if (level === 'Red') return { bg: 'bg-[#E76F51]', text: 'text-[#E76F51]', icon: AlertTriangle };
    if (level === 'Yellow') return { bg: 'bg-[#F4A261]', text: 'text-[#F4A261]', icon: AlertTriangle };
    return { bg: 'bg-[#6A994E]', text: 'text-[#6A994E]', icon: CheckCircle };
  };

  const riskStyle = getRiskColor(aiData.physician.riskLevel);
  const RiskIcon = riskStyle.icon;

  return (
    <div className="p-8 max-w-5xl">
      <div className="mb-6">
        <h2 className="text-2xl text-[#0A1128] mb-2">AI-Powered Risk Assessment</h2>
        <p className="text-[#5A6B7C]">
          Machine learning analysis of patient data to predict clinical deterioration
        </p>
      </div>

      {/* Risk Stratification Gauge */}
      <div className="bg-white rounded-xl border border-[#E8EEF2] shadow-sm p-8 mb-6">
        <div className="flex items-start gap-8">
          <div className="flex-1">
            <h3 className="text-lg text-[#0A1128] mb-6">Weekly Risk Stratification</h3>

            {/* Visual Risk Gauge */}
            <div className="relative mb-8">
              <div className="flex gap-2 h-12 rounded-lg overflow-hidden">
                <div className="flex-1 bg-[#6A994E]" />
                <div className="flex-1 bg-[#F4A261]" />
                <div className="flex-1 bg-[#E76F51]" />
              </div>
              <div
                className="absolute top-0 h-12 w-1 bg-[#0A1128] shadow-lg transition-all"
                style={{ left: `${aiData.physician.riskScore}%` }}
              >
                <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-[#0A1128] text-white px-3 py-1 rounded text-sm font-medium whitespace-nowrap">
                  Risk Score: {aiData.physician.riskScore}
                </div>
              </div>
              <div className="flex justify-between mt-2 text-xs text-[#5A6B7C]">
                <span>Low Risk (0-33)</span>
                <span>Moderate (34-66)</span>
                <span>High Risk (67-100)</span>
              </div>
            </div>

            <div className={`flex items-center gap-3 p-4 rounded-lg ${riskStyle.bg}/10 mb-6`}>
              <RiskIcon className={`w-6 h-6 ${riskStyle.text}`} />
              <div>
                <p className={`font-medium ${riskStyle.text}`}>
                  {aiData.physician.riskLevel === 'Yellow' ? 'Moderate Risk Alert' :
                   aiData.physician.riskLevel === 'Red' ? 'High Risk Alert' : 'Low Risk'}
                </p>
                <p className="text-sm text-[#5A6B7C]">
                  AI predicts moderate risk of clinical deterioration within 2 weeks
                </p>
              </div>
            </div>
          </div>

          <div className="w-48 bg-gradient-to-br from-[#2D9596] to-[#1a7273] rounded-xl p-6 text-white">
            <TrendingUp className="w-8 h-8 mb-4 opacity-80" />
            <p className="text-sm opacity-90 mb-2">Prediction Confidence</p>
            <p className="text-4xl font-semibold">87%</p>
          </div>
        </div>
      </div>

      {/* Key Clinical Findings */}
      <div className="bg-white rounded-xl border border-[#E8EEF2] shadow-sm p-8">
        <h3 className="text-lg text-[#0A1128] mb-6">Key Clinical Findings</h3>

        <div className="space-y-4">
          {aiData.physician.keyFindings.map((finding, index) => (
            <div
              key={index}
              className="flex items-start gap-4 p-4 bg-[#E8EEF2] rounded-lg"
            >
              <div className="w-8 h-8 bg-[#2D9596] text-white rounded-full flex items-center justify-center flex-shrink-0 font-medium">
                {index + 1}
              </div>
              <p className="text-[#0A1128] leading-relaxed">{finding}</p>
            </div>
          ))}
        </div>

        <div className="mt-8 pt-6 border-t border-[#E8EEF2]">
          <h4 className="text-sm font-medium text-[#0A1128] mb-4">AI Model Details</h4>
          <div className="grid grid-cols-3 gap-4 text-sm">
            <div>
              <p className="text-[#5A6B7C] mb-1">Model Version</p>
              <p className="text-[#0A1128] font-medium">SleepAI v2.4.1</p>
            </div>
            <div>
              <p className="text-[#5A6B7C] mb-1">Data Points Analyzed</p>
              <p className="text-[#0A1128] font-medium">1,247</p>
            </div>
            <div>
              <p className="text-[#5A6B7C] mb-1">Last Updated</p>
              <p className="text-[#0A1128] font-medium">April 14, 2026</p>
            </div>
          </div>
        </div>

        <div className="mt-6 bg-[#2D9596]/5 border border-[#2D9596]/20 rounded-lg p-4">
          <p className="text-xs text-[#5A6B7C]">
            <strong className="text-[#0A1128]">Clinical Note:</strong> AI predictions are
            intended to supplement, not replace, clinical judgment. All recommendations should
            be reviewed in context of the complete patient profile.
          </p>
        </div>
      </div>
    </div>
  );
}
