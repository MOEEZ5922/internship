import { useState } from 'react';
import { interventionData } from '../../data/mockData';
import { FileSignature } from 'lucide-react';

export default function PhysicianInterventions() {
  const [selectedTherapy, setSelectedTherapy] = useState('');
  const [clinicalNotes, setClinicalNotes] = useState('');

  const handleAuthorize = () => {
    alert(`Authorization submitted for: ${selectedTherapy}\n\nClinical Notes:\n${clinicalNotes}`);
  };

  return (
    <div className="p-8 max-w-4xl">
      <div className="bg-white rounded-xl border border-[#E8EEF2] shadow-sm p-8">
        <div className="mb-8">
          <h2 className="text-2xl text-[#0A1128] mb-2">Alternative Therapy Authorization</h2>
          <p className="text-[#5A6B7C]">
            Complete this form to authorize alternative sleep apnea treatments for the patient.
          </p>
        </div>

        <div className="space-y-6">
          {/* Therapy Selection */}
          <div>
            <label className="block text-sm font-medium text-[#0A1128] mb-3">
              Select Alternative Therapy
            </label>
            <div className="space-y-3">
              {interventionData.physician.availableTherapies.map((therapy) => (
                <label
                  key={therapy}
                  className={`flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                    selectedTherapy === therapy
                      ? 'border-[#2D9596] bg-[#2D9596]/5'
                      : 'border-[#E8EEF2] hover:border-[#2D9596]/50'
                  }`}
                >
                  <input
                    type="radio"
                    name="therapy"
                    value={therapy}
                    checked={selectedTherapy === therapy}
                    onChange={(e) => setSelectedTherapy(e.target.value)}
                    className="w-5 h-5 text-[#2D9596] border-[#E8EEF2]"
                  />
                  <span className="text-[#0A1128]">{therapy}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Clinical Indication */}
          <div>
            <label className="block text-sm font-medium text-[#0A1128] mb-3">
              Clinical Indication & Notes
            </label>
            <textarea
              value={clinicalNotes}
              onChange={(e) => setClinicalNotes(e.target.value)}
              placeholder="Enter clinical justification, patient history, contraindications, and any relevant notes..."
              className="w-full h-40 px-4 py-3 rounded-lg border border-[#E8EEF2] focus:border-[#2D9596] focus:ring-2 focus:ring-[#2D9596]/20 transition-all resize-none"
            />
            <p className="text-xs text-[#5A6B7C] mt-2">
              Include relevant diagnostic findings, prior treatment outcomes, and rationale for therapy change.
            </p>
          </div>

          {/* Patient Information Summary */}
          <div className="bg-[#E8EEF2] rounded-lg p-6">
            <h4 className="text-sm font-medium text-[#0A1128] mb-4">Current Treatment Summary</h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-[#5A6B7C] mb-1">Current Therapy</p>
                <p className="text-[#0A1128] font-medium">CPAP (Active)</p>
              </div>
              <div>
                <p className="text-[#5A6B7C] mb-1">Current AHI</p>
                <p className="text-[#0A1128] font-medium">4.2 events/hour</p>
              </div>
              <div>
                <p className="text-[#5A6B7C] mb-1">Compliance</p>
                <p className="text-[#0A1128] font-medium">6.8 hrs/night (Good)</p>
              </div>
              <div>
                <p className="text-[#5A6B7C] mb-1">Treatment Duration</p>
                <p className="text-[#0A1128] font-medium">14 months</p>
              </div>
            </div>
          </div>

          {/* Authorization Button */}
          <button
            onClick={handleAuthorize}
            disabled={!selectedTherapy || !clinicalNotes}
            className="w-full bg-[#2D9596] text-white px-6 py-4 rounded-lg hover:bg-[#247a7a] disabled:bg-[#E8EEF2] disabled:text-[#5A6B7C] disabled:cursor-not-allowed transition-all flex items-center justify-center gap-3 shadow-lg shadow-[#2D9596]/20 disabled:shadow-none"
          >
            <FileSignature className="w-5 h-5" />
            <span className="font-medium">Authorize & Sign</span>
          </button>

          <p className="text-xs text-[#5A6B7C] text-center">
            By clicking "Authorize & Sign", you are electronically signing this authorization form.
            This action will be logged in the patient's medical record.
          </p>
        </div>
      </div>
    </div>
  );
}
