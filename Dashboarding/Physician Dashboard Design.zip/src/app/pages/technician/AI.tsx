import { aiData } from '../../data/mockData';
import { AlertTriangle, Phone } from 'lucide-react';

export default function TechnicianAI() {
  const isHighRisk = aiData.technician.dropoutProbability > 20;

  return (
    <div className="p-8 max-w-4xl">
      {/* Alert Banner */}
      {isHighRisk && (
        <div className="mb-6 bg-[#E76F51]/10 border-2 border-[#E76F51] rounded-xl p-6 flex items-start gap-4">
          <AlertTriangle className="w-8 h-8 text-[#E76F51] flex-shrink-0" />
          <div>
            <h3 className="text-lg text-[#E76F51] font-semibold mb-2">High Dropout Risk Alert</h3>
            <p className="text-[#0A1128]">
              AI predicts this patient has a high probability of discontinuing therapy. Immediate
              intervention recommended.
            </p>
          </div>
        </div>
      )}

      {/* Dropout Probability */}
      <div className="bg-white rounded-xl border border-[#E8EEF2] shadow-sm p-8 mb-6">
        <h2 className="text-2xl text-[#0A1128] mb-6">AI Dropout Prediction</h2>

        <div className="flex items-center gap-8 mb-8">
          <div className="flex-1">
            <div className="relative h-4 bg-[#E8EEF2] rounded-full overflow-hidden">
              <div
                className={`absolute top-0 left-0 h-full ${
                  aiData.technician.dropoutProbability > 20 ? 'bg-[#E76F51]' : 'bg-[#F4A261]'
                } transition-all`}
                style={{ width: `${aiData.technician.dropoutProbability}%` }}
              />
            </div>
            <div className="flex justify-between mt-2 text-xs text-[#5A6B7C]">
              <span>Low Risk</span>
              <span>Moderate</span>
              <span>High Risk</span>
            </div>
          </div>
          <div className="text-center">
            <p className="text-5xl font-semibold text-[#F4A261]">
              {aiData.technician.dropoutProbability}%
            </p>
            <p className="text-sm text-[#5A6B7C] mt-1">Dropout Probability</p>
          </div>
        </div>

        <div className="bg-[#F4A261]/10 border border-[#F4A261]/20 rounded-lg p-4">
          <p className="text-sm text-[#0A1128] font-medium mb-2">AI Recommendation:</p>
          <p className="text-[#5A6B7C]">{aiData.technician.recommendation}</p>
        </div>
      </div>

      {/* Risk Factors */}
      <div className="bg-white rounded-xl border border-[#E8EEF2] shadow-sm p-8 mb-6">
        <h3 className="text-lg text-[#0A1128] mb-6">Mechanical & Usage Risk Factors</h3>

        <div className="space-y-4">
          {aiData.technician.riskFactors.map((factor, index) => (
            <div
              key={index}
              className="flex items-start gap-4 p-4 bg-[#E8EEF2] rounded-lg"
            >
              <div className="w-8 h-8 bg-[#F4A261] text-white rounded-full flex items-center justify-center flex-shrink-0 font-medium">
                {index + 1}
              </div>
              <p className="text-[#0A1128] leading-relaxed">{factor}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Action Items */}
      <div className="bg-gradient-to-br from-[#F4A261] to-[#e39350] rounded-xl p-8 text-white">
        <h3 className="text-xl mb-4">Recommended Actions</h3>
        <ul className="space-y-3 mb-6">
          <li className="flex items-start gap-2">
            <span>•</span>
            <span>Contact patient to schedule mask refit appointment</span>
          </li>
          <li className="flex items-start gap-2">
            <span>•</span>
            <span>Assess comfort issues that may be causing 3 AM mask removal</span>
          </li>
          <li className="flex items-start gap-2">
            <span>•</span>
            <span>Review machine settings and leak data from April 11th</span>
          </li>
        </ul>

        <button className="w-full bg-white text-[#F4A261] px-6 py-3 rounded-lg hover:bg-white/90 transition-colors flex items-center justify-center gap-2 font-medium">
          <Phone className="w-5 h-5" />
          Call Patient Now
        </button>
      </div>
    </div>
  );
}
