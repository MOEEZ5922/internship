import { Bug, HelpCircle, AlertCircle } from 'lucide-react';
import { useState } from 'react';

export default function TechnicianHelp() {
  const [ticketType, setTicketType] = useState('');
  const [description, setDescription] = useState('');

  const handleSubmit = () => {
    alert(`Support ticket submitted:\n\nType: ${ticketType}\nDescription: ${description}`);
    setTicketType('');
    setDescription('');
  };

  return (
    <div className="p-8 max-w-4xl">
      <div className="mb-6">
        <h2 className="text-2xl text-[#0A1128] mb-2">IT Support & Ticketing</h2>
        <p className="text-[#5A6B7C]">Report technical issues and get help from IT support</p>
      </div>

      {/* Submit Ticket Form */}
      <div className="bg-white rounded-xl border border-[#E8EEF2] shadow-sm p-8 mb-6">
        <h3 className="text-lg text-[#0A1128] mb-6">Submit Support Ticket</h3>

        <div className="space-y-6">
          {/* Ticket Type */}
          <div>
            <label className="block text-sm font-medium text-[#0A1128] mb-3">
              Issue Type
            </label>
            <div className="space-y-3">
              <label
                className={`flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                  ticketType === 'Hardware Malfunction'
                    ? 'border-[#F4A261] bg-[#F4A261]/5'
                    : 'border-[#E8EEF2] hover:border-[#F4A261]/50'
                }`}
              >
                <input
                  type="radio"
                  name="ticketType"
                  value="Hardware Malfunction"
                  checked={ticketType === 'Hardware Malfunction'}
                  onChange={(e) => setTicketType(e.target.value)}
                  className="w-5 h-5 text-[#F4A261] border-[#E8EEF2]"
                />
                <Bug className="w-5 h-5 text-[#F4A261]" />
                <span className="text-[#0A1128]">Hardware Malfunction</span>
              </label>

              <label
                className={`flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                  ticketType === 'System Sync Error'
                    ? 'border-[#F4A261] bg-[#F4A261]/5'
                    : 'border-[#E8EEF2] hover:border-[#F4A261]/50'
                }`}
              >
                <input
                  type="radio"
                  name="ticketType"
                  value="System Sync Error"
                  checked={ticketType === 'System Sync Error'}
                  onChange={(e) => setTicketType(e.target.value)}
                  className="w-5 h-5 text-[#F4A261] border-[#E8EEF2]"
                />
                <AlertCircle className="w-5 h-5 text-[#F4A261]" />
                <span className="text-[#0A1128]">System Sync Error</span>
              </label>

              <label
                className={`flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                  ticketType === 'Other Technical Issue'
                    ? 'border-[#F4A261] bg-[#F4A261]/5'
                    : 'border-[#E8EEF2] hover:border-[#F4A261]/50'
                }`}
              >
                <input
                  type="radio"
                  name="ticketType"
                  value="Other Technical Issue"
                  checked={ticketType === 'Other Technical Issue'}
                  onChange={(e) => setTicketType(e.target.value)}
                  className="w-5 h-5 text-[#F4A261] border-[#E8EEF2]"
                />
                <HelpCircle className="w-5 h-5 text-[#F4A261]" />
                <span className="text-[#0A1128]">Other Technical Issue</span>
              </label>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-[#0A1128] mb-3">
              Issue Description
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe the issue in detail. Include error messages, patient serial number, and steps to reproduce..."
              className="w-full h-40 px-4 py-3 rounded-lg border border-[#E8EEF2] focus:border-[#F4A261] focus:ring-2 focus:ring-[#F4A261]/20 transition-all resize-none"
            />
          </div>

          {/* Submit Button */}
          <button
            onClick={handleSubmit}
            disabled={!ticketType || !description}
            className="w-full bg-[#F4A261] text-white px-6 py-4 rounded-lg hover:bg-[#e39350] disabled:bg-[#E8EEF2] disabled:text-[#5A6B7C] disabled:cursor-not-allowed transition-all shadow-lg shadow-[#F4A261]/20 disabled:shadow-none"
          >
            Submit Support Ticket
          </button>
        </div>
      </div>

      {/* Quick Help Resources */}
      <div className="bg-[#E8EEF2] rounded-xl p-6">
        <h4 className="text-sm font-medium text-[#0A1128] mb-4">Quick Help Resources</h4>
        <div className="space-y-2 text-sm text-[#5A6B7C]">
          <p>
            • <strong>System not syncing?</strong> Check patient's WiFi connection and machine
            power status
          </p>
          <p>
            • <strong>Data missing?</strong> Verify machine has been used in the last 24 hours
          </p>
          <p>
            • <strong>For urgent issues:</strong> Call IT Support at 1-800-555-TECH (8324)
          </p>
        </div>
      </div>
    </div>
  );
}
